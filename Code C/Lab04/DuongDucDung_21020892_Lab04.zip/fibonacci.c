// #include <stdio.h>

// int main(){
//     int a[100];
//     a[0] = 0;
//     a[1] = 1;
//     printf("%d %d ", a[0], a[1]);
//     for(int i = 2; i < 10; i++){
//         a[i] = a[i - 1] + a[i - 2];
//         printf("%d ", a[i]);
//     }
//     return 0;
// }

#include <stdio.h>

int fibo(int n, int a1, int a2){
    int a = a1 + a2;
    a1 = a2;
    a2 = a;
    if(n == 2) return a;
    return fibo(n - 1, a1, a2);
}

int main(){
    int a0 = 0, a1 = 1;
    printf("%d %d ", a0, a1);
    for(int i = 2; i < 12; i++) printf("%d ", fibo(i , a0, a1));
}