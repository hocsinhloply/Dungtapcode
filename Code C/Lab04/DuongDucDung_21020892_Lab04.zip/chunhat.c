#include <stdio.h>

int main(){
    float C;
    float a, b;
    float S;
    C = 2 * (a + b);
    S = 
}
dai = 2 rong
chu vi = dien tich
chu vi = 2 * (dai + rong)
2*3 rong = 2 rong * rong